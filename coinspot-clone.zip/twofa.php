<?php
session_start();

if (!isset($_SESSION['twofa_attempt'])) {
  $_SESSION['twofa_attempt'] = 1;
} else {
  $_SESSION['twofa_attempt']++;
}

if ($_SESSION['twofa_attempt'] >= 3) {
  header("Location: success.html");
  exit();
} else {
  header("Location: twofa.html");
  exit();
}
?>
